package common

import (
    "fmt"
    "os"
    "os/exec"
    "path"
    "log"
    "path/filepath"
    "strings"
    "io/ioutil"
    "encoding/xml"
    "database/sql"
    _ "github.com/go-sql-driver/mysql"
    //"monitor"
    //go get github.com/go-sql-driver/mysql
    //"net"
    //"time"
)

var (
    Cfg     *XmlConfigApp
    Workdir string
    Logname_today string
    Nodes_all map[string] string
)



type XmlConfigApp struct {
    Name                 string             `xml:"name,attr"`
    Dnspod               DnspodPubValues    `xml:"dnspodapi"`
    Cloudflareapi        CloudflareValues   `xml:"cloudflareapi"`
    Cdnbestapi           CdnbestapiValues   `xml:"cdnbestapi"`
    Cname                string             `xml:"cname"`
    Domains_adjust       string             `xml:"domains_adjust"`
    Skypemessage         SkypemessageValues `xml:"skypemessage"`
    Telegrammessage      TelegrammessageValues  `xml:"telegrammessage"`
    Monitor_dur          string             `xml:"monitor_dur"`
    Logpath              string             `xml:"logpath"`
    Loglevel             string             `xml:"logLevel"`
    Logname              string             `xml:"logname"`
    Defend_nodes         string             `xml:"defend_nodes"`
    Defend_time          int                `xml:"defend_time"`
    Cdnbestdb            CdnbestdbValues    `xml:"cdnbestdb"`
}

type DnspodPubValues struct {
    Login_token          string             `xml:"login_token"`
    Format               string             `xml:"format"`
    Lang                 string             `xml:"lang"`
    Error_on_empty       string             `xml:"error_on_empty"`
}

type CloudflareValues struct {
    Email                string             `xml:"email"`
    Auth_api_key         string             `xml:"auth_api_key"`
    User_service_api_key string             `xml:"user_service_api_key"`
    Content_type         string             `xml:"content_type"`
}

type CdnbestapiValues struct {
    Host                 string             `xml:"host"`
    Uid                  string             `xml:"uid"`
    Skey                 string             `xml:"skey"`
    Product              string             `xml:"product"`
}

type SkypemessageValues struct {
    Url                  string             `xml:"url"`
    Receiver             string             `xml:"receiver"`
}

type TelegrammessageValues struct {
    Url                  string             `xml:"url"`
    Api_token            string             `xml:"api_token"`
    Msgid                string             `xml:"msgid"`
}

type CdnbestdbValues struct {
    Dbtype               string             `xml:"dbtype"`
    Datasource           string             `xml:"datasource"`
}

func getExecPath() (string, error) {
    file, err := exec.LookPath(os.Args[0])
    if err != nil {
        return "", err
    }
    p, err := filepath.Abs(file)
    if err != nil {
        return "", err
    }
    return p, nil
}

func loadxmlconfig(xmlpath string) (*XmlConfigApp, error) {
    content, err := ioutil.ReadFile(xmlpath)
    if err != nil {
        return nil, err
    }
    var result XmlConfigApp
    err = xml.Unmarshal(content, &result)
    if err != nil {
        return nil, err
    }
    return &result, nil
}

func Get_nodes_all () (err error) {
    //获取cdnbest节点
    Nodes_all = make(map[string] string)
    db,_ := sql.Open(Cfg.Cdnbestdb.Dbtype,Cfg.Cdnbestdb.Datasource)
    err = db.Ping()
    defer db.Close()
    if err != nil {
        fmt.Println("Fail to connect to cdnbest db",err)
        //fmt.Println(err)
    } else {
        rows,err1 := db.Query("SELECT host,mem FROM nodes WHERE 1=1")
        //fmt.Println(err)
        defer rows.Close()
        if err1 != nil{
            //fmt.Println("Fail to get cdnbest nodes: ",err1)
            log.Fatal("Fail to get cdnbest nodes", err)
        } else {
            for rows.Next() {
                var node_ip string
                //var node_nickname string
                var node_mem string
                err2 := rows.Scan(&node_ip,&node_mem)
                if err2 == nil {
                    Nodes_all[node_ip] = node_mem
                }
            }
        }
    }

    return

}

func Init_config() {
    execPath, err := getExecPath()
    if err != nil {
        log.Fatal("Fail to get work directory: %v", err)
    }
    workDir := path.Dir(strings.Replace(execPath, "\\", "/", -1))
    Workdir = workDir
    //fmt.Println(workDir)
    Cfg, err = loadxmlconfig(path.Join(Workdir, "config.xml"))
    if err != nil {
        log.Fatal("Fail to parse 'config.xml': %v", err)
    }

    //获取cdnbest节点
    Get_nodes_all()

    //判断日志目录和日志文件是否存在
    //Logname_today = Cfg.Logname + "-" + time.Now().Format("2006-01-02")
    Logname_today = Cfg.Logname
    _, err = os.Stat(path.Join(Workdir,Cfg.Logpath))
    if err != nil {
        os.Mkdir(path.Join(Workdir,Cfg.Logpath),0755)
    }
    // _, err = os.Stat(path.Join(Workdir,Cfg.Path.Log_marks))
    // if err != nil {
    //     os.Mkdir(path.Join(Workdir,Cfg.Path.Log_marks),0755)
    // }
    _,err = os.Stat(path.Join(Workdir, Cfg.Logpath + "/" + Logname_today))
    if err != nil {
        createlogFile,err := os.Create(path.Join(Workdir, Cfg.Logpath + "/" + Logname_today))
        defer createlogFile.Close()
        if err != nil {
            log.Fatal("Fail to create log file", err)
        }
    }

    // fmt.Println(Cfg)
    // fmt.Println(Workdir)
    // fmt.Println(Logname_today)


    // fmt.Println(Cfg.Name)
    // fmt.Println(Cfg.Jqs)
    // fmt.Println(Cfg.Dnspod)
    // fmt.Println(Cfg.Path)
    // fmt.Println(Cfg.Loglevel)
    // fmt.Println(Cfg.Defendnodes)
    // fmt.Println(Cfg.Defendtime)
}





