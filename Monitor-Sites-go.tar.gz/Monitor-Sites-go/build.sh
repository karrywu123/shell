#!/bin/bash

ProjectPath=`pwd`
export GOPATH=$ProjectPath:$GOPATH
# if [ -z "$1" ]
# then
#         echo "place select a version to build...\n\n"
#         exit 1
# fi

# if [ "X$1" = "Xtest" ]
# then
#         go test -v $2
#         exit 0
# fi

# if [ "X$1" = "Xbench" ]
# then
#         go test -test.bench=".*"
#         exit 0
# fi

rm -rf $ProjectPath/bin/*
cp -r $ProjectPath/config.xml $ProjectPath/bin/config.xml
#mkdir $ProjectPath/bin/log

cd $ProjectPath
echo "Updating..."
svn up

echo "Building..."

go build -ldflags "-X config.VERSION=$1"  -o ./bin/node-monitor ./src/node-monitor.go