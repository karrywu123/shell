package main

import (
    "fmt"
    "common"
    "time"
    "github.com/robfig/cron"
    "runtime"
    "monitor"
    // "os"


    //"api"
    //"strconv"
    //"encoding/json"


)

func running() {
    t := time.Now()
    fmt.Println("***************************" + time.Now().Format("2006-01-02 15:04:05") + "***************************")
    //monitor.Send_Skype_message("test123456")
    monitor.Monitor_nodes()

    fmt.Println(time.Since(t))

}

func main() {
    runtime.GOMAXPROCS(runtime.NumCPU())
    common.Init_config()
    // monitor.Send_Telegram_message("test message from Modify_nodes")
    // os.Exit(3)
    //test
    //status,err := api.Add_record_cf("defend001.com","A","test","192.168.1.1")
    // status,err := api.Del_record_cf("defend001.com","test")
    // if err == nil {
    //     fmt.Println(status)
    // } else {
    //     fmt.Println(err)
    // }
    //monitor.Adjust_DNSPod_to_CFrecord()

    //fmt.Println(common.Cfg.Cloudflareapi)
    //test

    go monitor.Adjust_record()
    go monitor.Purge_cache()

    spec := fmt.Sprintf("*/%s * * * * ?",common.Cfg.Monitor_dur)
    c := cron.New()
    c.AddFunc(spec, running)
    c.Start()
    select{}
}

