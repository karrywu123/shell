# -*- coding:utf-8 -*-
import sys
sys.path.append("..")

import re

pattern = re.compile(
    r'^((\*)|([a-zA-Z]{1})|([a-zA-Z]{1}[a-zA-Z]{1})|'
    r'([a-zA-Z]{1}[0-9]{1})|([0-9]{1}[a-zA-Z]{1})|'
    r'([a-zA-Z0-9][-_.a-zA-Z0-9]{0,61}[a-zA-Z0-9]))\.'
    r'([a-zA-Z]{2,13}|[a-zA-Z0-9-]{2,30}.[a-zA-Z]{2,3})$'
)

def domains_to_domainlist(domains):
    domainlist = domains.split(',')
    return domainlist

#判断域名是否符合规定
def check_domain_valid(domain):
    return True if pattern.match(domain) else False

def check_domains_valid(domains):
    domainlist = domains_to_domainlist(domains)
    all_status = 1
    for domain in domainlist:
        if check_domain_valid(domain) == False:
            print("域名不符合正常域名规范,域名:::",domain)
            all_status = 0
    if all_status == 0:
        print("域名不符合正常域名规范,请确认!!!")
        exit(1)
