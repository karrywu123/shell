# -*- coding:utf-8 -*-

import sys
sys.path.append("..")
import modules.database as DB_conn 
import platform
import os

if platform.system() == "Linux":
    cdn_home_path = "/vhs/kangle/cdn_home/"
else:
    cdn_home_path = "./"

#判断站点证书文件是否存在
def check_site_crt_key_exsit(sitename):
    crt_file_path = cdn_home_path + sitename + ".server.crt"
    key_file_path = cdn_home_path + sitename + ".server.key"

    if os.path.exists(crt_file_path) == False:
        print("crt不存在:::",crt_file_path)
        exit(1)
    if os.path.exists(key_file_path) == False:
        print("key不存在:::",key_file_path)
        exit(1)
    # print(crt_file_path)
    # print(key_file_path)

def read_site_crt(sitename):
    crt_file_path = cdn_home_path + sitename + ".server.crt"
    f = open(crt_file_path)
    lines = f.read()
    f.close()
    return lines

def read_site_key(sitename):
    key_file_path = cdn_home_path + sitename + ".server.key"
    f = open(key_file_path)
    lines = f.read()
    f.close()
    return lines


def read_site_domain_crt(sitename,domain):
    crt_file_path = cdn_home_path + sitename + "_" + domain+ ".server.crt"
    f = open(crt_file_path)
    lines = f.read()
    f.close()
    return lines
def read_site_domain_key(sitename,domain):
    key_file_path = cdn_home_path + sitename + "_" + domain+ ".server.key"
    f = open(key_file_path)
    lines = f.read()
    f.close()
    return lines

#判断站点某个域名证书文件是否存在
def check_site_domain_crt_key_exsit(sitename,domain):
    crt_file_path = cdn_home_path + sitename + "_" + domain+ ".server.crt"
    key_file_path = cdn_home_path + sitename + "_" + domain+ ".server.key"
    
    if os.path.exists(crt_file_path) == False:
        print("crt不存在:::",crt_file_path)
        exit(1)
    if os.path.exists(key_file_path) == False:
        print("key不存在:::",key_file_path)
        exit(1)
    # print(crt_file_path)
    # print(key_file_path)

