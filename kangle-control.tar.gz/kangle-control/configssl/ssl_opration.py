# -*- coding:utf-8 -*-

import sys
sys.path.append("..")
import modules.database as DB_conn
import json
import configssl.ssl_file as ssl_file_op
import configsite.generate_xml_access as xml_access
from xml.etree.ElementTree import Element
import configsite.access_xml_template as xml_template
from jinja2 import Template

def dict_to_xml(tag, d):
    '''
    Turn a simple dict of key/value pairs into XML
    '''
    elem = Element(tag)
    for key, val in d.items():
        child = Element(key)
        child.text = str(val)
        elem.append(child)
    return elem

def domains_to_domainlist(domains):
    domainlist = domains.split(',')
    return domainlist

def checkdomain_bind(domain):
    res = DB_conn.get_domain_from_all_site(domain)
    if res:
        return 1
    else:
        return 0

#查看域名是否绑定,如果有未绑定的域名,直接退出,不执行操作
def checkdomains_bind(domains):
    domainlist = domains_to_domainlist(domains)
    all_status = 1
    for domain in domainlist:
        if checkdomain_bind(domain) == 0:
            print("域名未绑定,域名:::",domain)
            all_status = 0
    if all_status == 0:
        print("以上域名未绑定,请绑定后重试!!!")
        exit(1)

#判断某个域名是否已经添加301
def checkdomain_301(sitename,domain):
    res = DB_conn.select_vhost_config_301(sitename)
    domain_host = "^http://" + domain+ "/(.*)$"
    status = 0
    for redirect in res:
        item301 = json.loads(redirect[1])
        # print(item301)
        if domain_host == item301["host"]:
            status = 1

    return status
        # print(redirect[0],domain_host,item301["code"],item301["host"],item301["target"])

#判断域名是否已经添加301，如果已经添加，直接退出，应该删除之后再进行添加;添加证书域名时
def checkdomains_301(sitename,domains):
    domainlist = domains_to_domainlist(domains)
    all_status = 0
    for domain  in domainlist:
        if checkdomain_301(sitename,domain) == 1:
            print("域名已经添加301重写,域名:::",domain)
            all_status = 1
    if all_status == 1:
        print("以上域名已经添加301，请删除后重试!!!")
        exit(1)

#判断域名是否已经添加301，如果有域名没有添加，直接退出;删除证书域名时
def checkdomains_301_not(sitename,domains):
    domainlist = domains_to_domainlist(domains)
    all_status = 1
    for domain  in domainlist:
        if checkdomain_301(sitename,domain) == 0:
            print("域名没有添加301重写,域名:::",domain)
            all_status = 0
    if all_status == 0:
        print("以上域名没有添加301，请添加后重试!!!")
        exit(1)

#为域名分配301跳转字段id,在最大的数字上面加1
def getdomain_301_id(sitename,domain):
    res = DB_conn.select_vhost_config_301(sitename)
    if res:
        newid = res[-1][0] + 1
    else:
        newid = 1
    return newid

#为域名添加301跳转
def insert_domains_301(sitename,domains):
    domainlist = domains_to_domainlist(domains)
    for domain in domainlist:
        data_301_map = {
            "code":301,
            "host":"^http://" + domain+ "/(.*)$",
            "target":"https://" + domain + "/$1"
        }
        
        data_301 = json.dumps(data_301_map).replace("/","\/")
        vhost_config_301_data = [sitename,"redirect",getdomain_301_id(sitename,domain)]
        # print(vhost_config_301_data)
        # print([data_301])
        print("Insert vhost_config 301 ::: ",DB_conn.insert_vhost_config_301(vhost_config_301_data,data_301))

#删除域名301跳转
def delete_domains_301(sitename,domains):
    domainlist = domains_to_domainlist(domains)
    for domain in domainlist:
        res = DB_conn.select_vhost_config_301(sitename)
        domain_host = "^http://" + domain+ "/(.*)$"
        for redirect in res:
            item301 = json.loads(redirect[1])
            if domain_host == item301["host"]:
                data = [sitename,"redirect",redirect[0]]
                print("Delete vhost_config 301 :::",DB_conn.delete_vhost_config_301(data))

#生成301配置xml
def generate_xml_domains(sitename,domains):
    domainlist = domains_to_domainlist(domains)
    for domain in domainlist:
        res = DB_conn.select_vhost_config_301(sitename)
        domain_host = "^http://" + domain+ "/(.*)$"
        if res:
            for redirect in res:
                item301 = json.loads(redirect[1])
                if domain_host == item301["host"]:
                    num = redirect[0]
                    code = item301["code"]
                    host = item301["host"]
                    target = item301["target"]
                    xml_data_tmplate = Template(xml_template.xml_301)
                    print(xml_data_tmplate.render(num=num,code=code,host=host,target=target))

#设置vhost_config https字段
def vhost_config_https_set(sitename):
    #插入证书信息到vhost_config
    https_data_map = {
        "certificate": ssl_file_op.read_site_crt(sitename),
        "key": ssl_file_op.read_site_key(sitename),
        "cipher":"",
        "protocols":"",
        "http2": 1,
        "hsts":0
    }
    https_data = json.dumps(https_data_map)
    
    res = DB_conn.select_vhost_config_ssl(sitename)
    if res:
        print("Update vhost_config https :::",DB_conn.update_vhost_config_ssl(sitename,https_data))
    else:
        vhost_config_ssl_data = [sitename,"https",1]
        print("Insert vhost_config https ::: ",DB_conn.insert_vhost_config_ssl(vhost_config_ssl_data,https_data))

#检查单独域名证书状态
def get_domain_alone_https_status(sitename,domain):
    res = DB_conn.select_domain_setting_from_site(sitename,domain)
    status = 0
    if res:
        for domain_item in res:
            if domain_item[2]:
                # print("testjajaja",domain_item[2])
                domain_public_setting = json.loads(domain_item[2])
                if 'sslcsr' in domain_public_setting.keys():
                # if domain_public_setting["force_ssl"] == 0 or domain_public_setting["force_ssl"] == 1:
                    status = 1
    return status
def check_domain_alone_https(sitename,domain):
    status=get_domain_alone_https_status(sitename,domain)
    if status == 1:
        print("以上域名已经添加单独https，请删除后重试!!!")
        exit(1)

def check_domain_alone_https_not(sitename,domain):
    status=get_domain_alone_https_status(sitename,domain)
    if status == 0:
        print("以上域名没有添加单独https，请添加后再删除!!!")
        exit(1)

def domain_site_https_set(sitename,domain):
    #默认设置强制https
    https_data_map = {
        "force_ssl":1,
        "sslcsr":ssl_file_op.read_site_domain_crt(sitename,domain),
        "sslkey":ssl_file_op.read_site_domain_key(sitename,domain),
        "hash":"",
        "max_error_count":"",
        "error_try_time":"",
        "hsts":0,
        "portmap":0
    }
    https_data = json.dumps(https_data_map)
    print("Update site domain https :::",DB_conn.update_domain_setting_from_site(sitename,domain,https_data))

def domain_site_https_delete(sitename,domain):
    print("Delete site domain https :::",DB_conn.update_domain_setting_from_site(sitename,domain,""))

def vhost_info_domain_https_set(sitename,domain):
    res = DB_conn.get_vhost_info_domain(sitename,domain)
    if res:
        for item in res:
            value = res[0][0]
            crt_name = sitename + "_" + domain+ ".server.crt"
            key_name = sitename + "_" + domain+ ".server.key"
            newvalue = value + ";" + crt_name + "|" + key_name
            data = [newvalue]
            print("Update vhost_info domain https value ::: ",DB_conn.update_domain_info_https_from_vhost_info(sitename,domain,data))

def vhost_info_domain_https_delete(sitename,domain):
    res = DB_conn.get_vhost_info_domain(sitename,domain)
    if res:
        for item in res:
            value = res[0][0]
            valuelist = value.split(';')
            data = [valuelist[0]]
            print("Delete vhost_info domain https value ::: ",DB_conn.update_domain_info_https_from_vhost_info(sitename,domain,data))

#针对站点查询所有域名,判断是否有单独https,有的话就更新
def update_domain_alone_https_file(sitename):
    res = DB_conn.select_all_domain_setting_from_site(sitename)
    if res:
        for domain_item in res:
            status = get_domain_alone_https_status(sitename,domain_item[0])
            if status == 1:
                domain_site_https_set(sitename,domain_item[0])

# 检查vhost_info站点里面是否有443配置
def check_vhost_info_443_config(sitename):
    res = DB_conn.get_vhost_info_443_config(sitename)
    data = [sitename]
    if res:
        print("vhost表已存在443！,正常！")
    else:
        result = DB_conn.insert_to_vhost_info_ssl_config(data)
        print("插入443信息到vhast_info站点！！！")

def sitessladd(sitename,domains):
    #判断域名是否已经添加301，如果已经添加，直接退出，应该删除之后再进行添加
    checkdomains_301(sitename,domains)

    #更新站点指向证书
    crt_name = sitename + ".server.crt"
    key_name = sitename + ".server.key"
    vhost_ssl_data = [crt_name,key_name]
    print("Update vhost:::",DB_conn.update_vhost_ssl(sitename,vhost_ssl_data))

    #插入证书信息到vhost_config,存在就更新
    vhost_config_https_set(sitename)

    #插入301跳转信息
    insert_domains_301(sitename,domains)

    # 生成xml模范301配置,打印,让用户添加到对应的access.xml
    generate_xml_domains(sitename,domains)
    print("请将以上生成的301 xml 配置到:",xml_access.get_access_xml_path(sitename))
    

def sitessldel(sitename,domains):
    #判断域名是否已经添加301，如果没有添加，直接退出，应该添加之后再进行删除
    checkdomains_301_not(sitename,domains)

    #更新站点指向证书
    crt_name = sitename + ".server.crt"
    key_name = sitename + ".server.key"
    vhost_ssl_data = [crt_name,key_name]
    print("Update vhost:::",DB_conn.update_vhost_ssl(sitename,vhost_ssl_data))

    #插入证书信息到vhost_config,存在就更新
    vhost_config_https_set(sitename)

    #生成xml模范301配置,打印,让用户删除对应的access.xml
    generate_xml_domains(sitename,domains)
    print("请将以上生成的301 xml 删除:",xml_access.get_access_xml_path(sitename))

    #删除301跳转配置
    delete_domains_301(sitename,domains)

def domainssladd(sitename,domain):
    #判断域名是否已经添加域名证书，如果已经添加，直接退出，应该删除之后再进行添加
    check_domain_alone_https(sitename,domain)

    domain_site_https_set(sitename,domain)
    vhost_info_domain_https_set(sitename,domain)

    #插入301跳转信息
    insert_domains_301(sitename,domain)

    # 生成xml模范301配置,打印,让用户添加到对应的access.xml
    generate_xml_domains(sitename,domain)
    print("请将以上生成的301 xml 配置到:",xml_access.get_access_xml_path(sitename))

def domainssldel(sitename,domain):
    #判断域名是否已经添加域名证书，如果没有添加，直接退出，应该添加之后再进行删除
    check_domain_alone_https_not(sitename,domain)

    domain_site_https_delete(sitename,domain)
    vhost_info_domain_https_delete(sitename,domain)

    #生成xml模范301配置,打印,让用户删除对应的access.xml
    generate_xml_domains(sitename,domain)
    print("请将以上生成的301 xml 删除:",xml_access.get_access_xml_path(sitename))

    #删除301跳转配置
    delete_domains_301(sitename,domain)

def sslstatus(sitename):
    #单独域名证书更新
    update_domain_alone_https_file(sitename)

    #站点证书更新
    #查看站点证书文件是否存在
    ssl_file_op.check_site_crt_key_exsit(sitename)
    #插入证书信息到vhost_config,存在就更新
    vhost_config_https_set(sitename)
