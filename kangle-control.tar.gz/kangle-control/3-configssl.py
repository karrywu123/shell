#!/usr/local/bin/python3
# -*- coding:utf-8 -*-

import sys
import modules.getopts as get_opts
import modules.database as DB_conn
import configssl.ssl_file as ssl_file_op
import configssl.ssl_opration as ssl_op
import configsite.site_opration as site_op
import configdomain.domain_opration as domain_op

#交互性获取输入的参数
values = get_opts.get_options_configssl()
print(values)

if __name__ == '__main__':
    if sys.argv[1] == "sitessladd":
        #查看站点和域名是否存在
        domain_op.check_domains_valid(values['d'])
        site_op.check_site_exsit(values['s'])
        ssl_op.checkdomains_bind(values['d'])
        #查看站点证书文件是否存在
        ssl_file_op.check_site_crt_key_exsit(values['s'])
        # 查看vhost_info表443配置是否存在，不存在则插入
        ssl_op.check_vhost_info_443_config(values['s'])

        message = "请确认[Y/N]: "
        answer_1 = input(message).strip().upper()
        if answer_1 == "YES" or answer_1 == "Y":
            ssl_op.sitessladd(values['s'],values['d'])

    elif sys.argv[1] == "sitessldel":
        #查看站点和域名是否存在
        domain_op.check_domains_valid(values['d'])
        site_op.check_site_exsit(values['s'])
        ssl_op.checkdomains_bind(values['d'])
        #查看站点证书文件是否存在
        ssl_file_op.check_site_crt_key_exsit(values['s'])

        message = "请确认[Y/N]: "
        answer_1 = input(message).strip().upper()
        if answer_1 == "YES" or answer_1 == "Y":
            ssl_op.sitessldel(values['s'],values['d'])

    elif sys.argv[1] == "domainssladd":
        #查看站点和域名是否存在
        domain_op.check_domains_valid(values['d'])
        site_op.check_site_exsit(values['s'])
        ssl_op.checkdomains_bind(values['d'])
        #查看域名证书文件是否存在
        ssl_file_op.check_site_domain_crt_key_exsit(values['s'],values['d'])
        # 查看vhost_info表443配置是否存在，不存在则插入
        ssl_op.check_vhost_info_443_config(values['s'])

        message = "请确认[Y/N]: "
        answer_1 = input(message).strip().upper()
        if answer_1 == "YES" or answer_1 == "Y":
            ssl_op.domainssladd(values['s'],values['d'])

    elif sys.argv[1] == "domainssldel":
        #查看站点和域名是否存在
        domain_op.check_domains_valid(values['d'])
        site_op.check_site_exsit(values['s'])
        ssl_op.checkdomains_bind(values['d'])
        #查看域名证书文件是否存在
        ssl_file_op.check_site_domain_crt_key_exsit(values['s'],values['d'])

        message = "请确认[Y/N]: "
        answer_1 = input(message).strip().upper()
        if answer_1 == "YES" or answer_1 == "Y":
            ssl_op.domainssldel(values['s'],values['d'])
 
    elif sys.argv[1] == "sslstatus":
        #查看站点是否存在
        site_op.check_site_exsit(values['s'])

        ssl_op.sslstatus(values['s'])

    else:
        # print help_info
        print("输入的参数有误，请确认后重试")
        exit(1)
