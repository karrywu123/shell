#!/usr/local/bin/python3
# -*- coding:utf-8 -*-

import sys
import time
import modules.getopts as get_opts
import modules.database as DB_conn
import configsite.access_xml_template as xml_template
import configsite.generate_xml_access as xml_file_op
# import platform

# print(platform.system())

#交互性获取输入的参数
values = get_opts.get_options_configsite()
# print(values)


if __name__ == '__main__':
    if sys.argv[1] == "siteadd":
        sites = DB_conn.getAllSite()
        site_list = []
        for site in  sites:
            site_list.append(str(site)[2:-3])
        print("All Site:::" , site_list)

        if values['s'] not in site_list:
            message = "添加站点，站点信息如下, sitename: " + values["s"] + " ,请确认[Y/N]: "
            answer_1 = input(message).strip().upper()
            if answer_1 == "YES" or answer_1 == "Y":
                vhost_data = [values['s'], 'cdn_home', '9999', '1100', 0, None, values['s'] + '.access.xml', 0, 0, 0, 0, '/nolog', 0, 0, 0, None, 0, 0, None, None, None, None, 1, 0, -1, '0 */1 * * *', ' ', 0]
                print("Insert vhost Res:::",DB_conn.insert_vhost(vhost_data))
                vhost_config_life_time_data = [values['s'], 'life_time', 1, '8']
                vhost_config_anticc_data = [values['s'], 'anticc', 1, '{"frequency":"high","frcquency":null,"model":1,"custom":null,"request":"800","second":"10","name_en":null}']
                vhost_config_ipfrequency_data = [values['s'], 'ipfrequency', 1, '{"type":0,"time":2000,"second":2,"exist_second":3600}']
                vhost_config_default_cache_data = [values['s'], 'default-cache', 1, '{"model":0,"second":"3600"}']
                vhost_config_gzip_data = [values['s'], 'gzip', 1, 'css,html,js']
                vhost_config_cache_flush_time_data = [values['s'], 'cache-flush-time', 1, '{"hard":1,"time":1619412490}']
                vhost_info_config_data = [values['s']]
                print("Insert vhost config,Res:::",DB_conn.insert_vhost_config(vhost_config_life_time_data))
                print("Insert vhost config,Res:::",DB_conn.insert_vhost_config(vhost_config_anticc_data))
                print("Insert vhost config,Res:::",DB_conn.insert_vhost_config(vhost_config_ipfrequency_data))
                print("Insert vhost config,Res:::",DB_conn.insert_vhost_config(vhost_config_default_cache_data))
                print("Insert vhost config,Res:::",DB_conn.insert_vhost_config(vhost_config_gzip_data))
                print("Insert vhost config,Res:::",DB_conn.insert_vhost_config(vhost_config_cache_flush_time_data))
                print("Insert vhost_info config,Res:::", DB_conn.insert_vhost_info_80_config(vhost_info_config_data))
                print("以下生成默认的access.xml,保存到 /vhs/kangle/cdn_home/" + values['s'] + ".access.xml")
                # print(xml_template.default_xml)
                print(xml_file_op.generate_default_xml_access(values['s'],xml_template.default_xml))
                res = DB_conn.get_Site(values['s'])
                if res:
                    print("新增站点" + str(values['s']) + "成功")
                else:
                    print("新增站点" + str(values['s']) + "失败")
                print("请确认好插入结果,并且测试绑定域名,测试是否正常!!!")
            
        else:
            print("该站点已存在,请确认后重试")
            exit(1)
    elif sys.argv[1] == "sitedel":
        sites = DB_conn.getAllSite()
        site_list = []
        for site in  sites:
            site_list.append(str(site)[2:-3])
        print("All Site:::" , site_list)
        if values['s']  in site_list:
            message = "删除站点，请谨慎操作，即将删除所有的站点信息和域名记录，站点信息如下, sitename: " + values["s"] + " ,请确认[Y/N]: "
            answer_1 = input(message).strip().upper()
            if answer_1 == "YES" or answer_1 == "Y":
                sitedata = []
                sitedata.append(str(values["s"]))
                # print(sitedata)
                
                print("Delete vhost,Res:::",DB_conn.delete_site_vhost(sitedata))
                print("Delete vhost,Res:::",DB_conn.delete_site_vhost_config(sitedata))
                print("Delete vhost,Res:::",DB_conn.delete_site_domain(sitedata))
                print("Delete vhost,Res:::",DB_conn.delete_site_vhost_info(sitedata))
                print("Delete vhost,Res:::",DB_conn.delete_site_vhost_port(sitedata))
                print("Delete vhost access.xml,Res:::",xml_file_op.delete_xml_access(values['s']))
                res = DB_conn.get_Site(values['s'])
                if res:
                    print("删除站点" + str(values['s']) + "失败")
                else:
                    print("删除站点" + str(values['s']) + "成功")
                print("请确认好插入结果,并且测试绑定域名,测试是否正常!!!")
        else:
            print("该站点不存在,请确认后重试")
            exit(1)  
    elif sys.argv[1] == "sitestatus":
        sites = DB_conn.getAllSite()
        site_list = []
        for site in  sites:
            site_list.append(str(site)[2:-3])
        if values['s'] in site_list:
            if values['p'] == '0':
                message = "修改站点 " + values["s"] + " 状态为 正常 ,请确认[Y/N]: "
                answer_1 = input(message).strip().upper()
                if answer_1 == "YES" or answer_1 == "Y":
                    vhost_status_data = [values['p'],values['s']]
                    DB_conn.update_vhost_status__from_vhost(vhost_status_data)
                    res = DB_conn.get_site_status(values['s'])
                    if res[0][0] == 0:
                        print("站点状态修改成功! 目前状态为 正常")
                    else:
                        print('站点状态修改失败！')
            elif values['p'] == '1':
                message = "修改站点 " + values["s"] + " 状态为 暂停 ,请确认[Y/N]: "
                answer_1 = input(message).strip().upper()
                if answer_1 == "YES" or answer_1 == "Y":
                    vhost_status_data = [values['p'], values['s']]
                    DB_conn.update_vhost_status__from_vhost(vhost_status_data)
                    res = DB_conn.get_site_status(values['s'])
                    if res[0][0] == 1:
                        print('站点状态修改成功！ 目前状态为 暂停')
                    else:
                        print('站点状态修改失败！')
            else:
                print('站点状态参数输入错误！ 请确认后重试')
        else:
            print("该站点不存在,请确认后重试")
            exit(1)
    else:
        print("输入的参数有误，请确认后重试")
        exit(1)
