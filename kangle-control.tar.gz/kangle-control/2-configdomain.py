#!/usr/local/bin/python3
# -*- coding:utf-8 -*-
import sys
# import modules.getopts as get_opts
from modules import getopts
import modules.database as DB_conn
import configdomain.domain_opration as domain_op

#交互性获取输入的参数
values = getopts.get_options_configdomain()
# print(values)

if __name__ == '__main__':
    if sys.argv[1] == "domainadd":
        domain_op.check_domains_valid(values['d'])
        sites = DB_conn.getAllSite()
        site_list = []
        for site in  sites:
            site_list.append(str(site)[2:-3])
        if values['s'] in site_list:
            site_new = values['s']
            domians = values['d'].split(',')
            message = "添加域名，即将添加域名记录，域名信息如下, domains: " + str(domians) + " ,请确认[Y/N]: "
            answer_1 = input(message).strip().upper()
            if answer_1 == "YES" or answer_1 == "Y":
                for domian in domians:
                    dms = DB_conn.get_domain_from_all_site(domian)
                    # print(dms)
                    if dms:
                        if str(dms[0][0]) != site_new:
                            print('重复的数据，该域名已被站点' + str(dms[0]) + '添加')
                        else:
                            ips = values['i'].split(',')
                            ip_list = []
                            ip_list1 = []
                            ip_list2 = []
                            data = []
                            domain_data = []
                            for ip in ips:
                                domain_details = DB_conn.get_domain_from_site(site_new, domian)
                                # if domain_details:
                                for domain_detail in domain_details:
                                    if domain_detail[0] == domian and domain_detail[1] == ip:
                                        print("错误，该域名记录已存在，请确认！")
                                        exit(1)
                                domainids = DB_conn.get_domain_id_from_site(site_new)
                                new_ids = []
                                for domainid in domainids:
                                    new_ids.append(str(domainid)[1:-2])
                                if len(new_ids) == 0:
                                    id = 1
                                else:
                                    id = str(int(new_ids[-1]) + 1)
                                domain_data = [site_new, id, domian, ip]
                                DB_conn.insert_to_domian(domain_data)
                                res = DB_conn.get_domain_info_from_all_site(domian, ip)
                                if res:
                                    print("域名" + domian + "插入domain表成功！")
                                else:
                                    print("域名" + domian + "插入domain表失败！，请检查！")

                            domain_details = DB_conn.get_domain_from_site(site_new, domian)
                            resoure_ip_list = []
                            for domain_detail in domain_details:
                                resoure_ip_list.append(domain_detail[1])
                            # print(resoure_ip_list)
                            i = len(resoure_ip_list)
                            for resoure_ip in resoure_ip_list:
                                if len(resoure_ip.split(':')) >= 2:
                                    ip_list.append(resoure_ip + ':8:1')
                                elif len(resoure_ip.split(':')) == 1:
                                    ip_list.append(resoure_ip + ':80:8:1')
                                    ip_list1.append(resoure_ip + ':443s:8:1')
                                ip_new1 = ','.join(ip_list)
                                ip_new2 = ','.join(ip_list1)
                                i = i - 1
                                if i == 0 :
                                    ip_list2.append(ip_new1)
                                    ip_list2.append(ip_new2)
                                    # print(ip_list2)
                                    ip_new = '|/nodes='.join(ip_list2)
                                    ip_new = 'server://nodes=' + ip_new + '/error_count=1/error_try_time=30'
                                    data = [site_new, domian, '0', ip_new, '0']

                            DB_conn.update_domain_info_from_vhost_info(data)
                            result = DB_conn.get_vhost_info_domain(site_new, domian)
                            if result:
                                if result[0][0] == data[3]:
                                    print(print("vhsot_info表" + domian + "域名信息更新成功!"))
                                else:
                                    print("vhsot_info表" + domian + "域名信息更新失败!")
                            else:
                                print('vhost_info表不存在该域名信息！')

                    else:
                        ips = values['i'].split(',')
                        ip_list = []
                        ip_list1 = []
                        ip_list2 = []
                        data = []
                        i = len(ips)
                        for ip in ips:
                            domainids = DB_conn.get_domain_id_from_site(site_new)
                            new_ids = []
                            for domainid in domainids:
                                new_ids.append(str(domainid)[1:-2])
                            if len(new_ids) == 0:
                                id = 1
                            else:
                                id = str(int(new_ids[-1]) + 1)
                            domain_data=[site_new,id,domian,ip]
                            DB_conn.insert_to_domian(domain_data)
                            res  = DB_conn.get_domain_info_from_all_site(domian,ip)
                            if res:
                                print("域名" + domian + "插入domain表成功！")
                            else:
                                print("域名" + domian + "插入domain表失败！，请检查！")

                            if len(ip.split(':')) >= 2:
                                ip_list.append(ip + ':8:1')
                                ip_new = ','.join(ip_list)
                                ip_new = 'server://nodes=' + ip_new + '/error_count=1/error_try_time=30'
                                # print(ip_new)
                                data = [site_new, domian, '0', ip_new, '0']
                                # print(res)
                            elif len(ip.split(':')) == 1:
                                ip_list.append(ip + ':80:8:1')
                                ip_list1.append(ip + ':443s:8:1')
                                ip_new1 = ','.join(ip_list)
                                ip_new2 = ','.join(ip_list1)
                                i = i-1
                                if i < 1:
                                    ip_list2.append(ip_new1)
                                    ip_list2.append(ip_new2)
                                    # print(ip_list2)
                                    ip_new = '|/nodes='.join(ip_list2)
                                    ip_new = 'server://nodes=' + ip_new + '/error_count=1/error_try_time=30'
                                    # print(ip_new)
                                    data = [site_new,domian,'0',ip_new,'0']
                        # print(data)
                        DB_conn.insert_to_vhost_info(data)
                        result = DB_conn.get_vhost_info_domain(site_new,domian)
                        if result:
                            if result[0][0] == data[3]:
                                print(print("vhsot_info表" + domian + "域名信息更新成功!"))
                            else:
                                print("vhsot_info表" + domian + "域名信息更新失败!")
                        else:
                            print('vhost_info表不存在该域名信息！')

        else:
            print("该站点不存在！")
            exit(1)
    elif sys.argv[1] == "domaindel":
        domain_op.check_domains_valid(values['d'])
        #删除domain表中的域名
        sites = DB_conn.getAllSite()
        site_list = []
        for site in sites:
            site_list.append(str(site)[2:-3])
        if values['s'] in site_list:
            site_new = values['s']
            domians = values['d'].split(',')
            message = "删除域名，请谨慎操作，即将删除域名记录，域名信息如下, domains: " + str(domians) + " ,请确认[Y/N]: "
            answer_1 = input(message).strip().upper()
            if answer_1 == "YES" or answer_1 == "Y":
                
                for domian in domians:
                    data=[]
                    domain_details = DB_conn.get_domain_from_site(site_new, domian)
                    print(domain_details)
                    if domain_details:
                        print('删除域名：' + domian)
                        data.append(domian)
                    else:
                        print("该域名不存在，请确认后重试！")
                    # print(data)
                    DB_conn.delete_domain_from_domain(data)
                    DB_conn.delete_domian_from_vhost_info(data)
        else:
            print("该站点不存在！")
    elif sys.argv[1] == "siteconfig":
        pass
    else:
        print("输入的参数有误，请确认后重试")
        exit(1)
