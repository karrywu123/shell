# -*- coding:utf-8 -*-

import sys
sys.path.append("..")
import modules.database as DB_conn

#查看操作的站点是否存在，不存在直接退出
def check_site_exsit(sitename):
    sites = DB_conn.getAllSite()
    site_list = []
    for site in  sites:
        site_list.append(str(site)[2:-3])
    if sitename not in site_list:
        print("站点不存在,请确认后重试")
        exit(1)