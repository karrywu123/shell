# -*- coding:utf-8 -*-

default_xml = '''<config>
	<request action='allow'>
		<table name='waf'>
			<chain  action='deny' name='ipfrequency'>
				<mark_check_black_list  time_out='3600'></mark_check_black_list>
			</chain>
			<chain action='deny'>
				<acl_ip_rate request='5000' second='2'></acl_ip_rate>
				<mark_black_list  ></mark_black_list>
			</chain>
			<chain action='continue' name='anticc'>
				<mark_anti_cc request='50' second='10' wl='1' fix_url='1'><![CDATA[HTTP/1.1 200 OK
Content-Type: text/html; charset=utf-8
Connection: close
Cache-Control: no-cache,no-store

<html><body><img src='/KANGLE_CCIMG.php?k={{session_key}}'><form action='/KANGLE_CCIMG.php' method='get'><input name='k' value='{{session_key}}' type='hidden'><input name='v' value=''/><input type='submit'/></form></body></html>]]></mark_anti_cc>
			</chain>
		</table>
		<table name='BEGIN'>
			<chain action='table:waf'>
			</chain>
			<chain  action='continue'>
				<mark_min_obj_verified   v='1620190770' hard='1'></mark_min_obj_verified>
			</chain>
		</table>
	</request>
	<response action='allow'>
		<table name='cache-setting'>
			<chain action='continue' name='default-cache'>
				<mark_cache_control   max_age='3600'></mark_cache_control>
			</chain>
		</table>
		<table name='BEGIN'>
			<chain action='table:cache-setting'></chain>			<chain  action='continue'  name='gzip'>
				<acl_header header='Content-Type' regex='1'><![CDATA[(text/css)|(text/ht*)|(javascript)]]></acl_header>
				<mark_response_flag   flagvalue='gzip'></mark_response_flag>
			</chain>
		</table>
	</response>
</config>
'''

xml_301 = '''
			<chain action='continue' name='redirect[{{ num }}]'>
				<mark_url_rewrite  url='{{ host }}' dst='{{ target }}' nc='1' code='{{ code }}'></mark_url_rewrite>
			</chain>
'''