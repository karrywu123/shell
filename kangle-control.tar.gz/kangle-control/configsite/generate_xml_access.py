# -*- coding:utf-8 -*-


import os
import platform

#access.xml保存路径
#cdn_home_path = "/vhs/kangle/cdn_home/"
# cdn_home_path = "./"

if platform.system() == "Linux":
    cdn_home_path = "/vhs/kangle/cdn_home/"
else:
    cdn_home_path = "./"

#sitename: 站点名字, xml_text xml内容
def generate_default_xml_access(sitename,xml_text):
    xml_name = sitename+ '.access.xml'
    xml_file_path = cdn_home_path + xml_name
    file = open(xml_file_path,"w")
    file.write(xml_text)
    file.close()

#删除某站点文件access.xml
def delete_xml_access(sitename):
    xml_name = sitename+ '.access.xml'
    xml_file_path = cdn_home_path + xml_name
    os.remove(xml_file_path)

def get_access_xml_path(sitename):
    xml_name = sitename+ '.access.xml'
    xml_path = cdn_home_path + xml_name
    return xml_path