# -*- coding:utf-8 -*-

import getopt,sys,os
# sys.path.append("..")
#import config
#import config_wapmodel
import re

def judge_site_name(sitename):
    if re.match("^[A-Za-z0-9_-]*$", sitename):
        return 1
    else:
        return 0

def get_options_configsite():
	help_info='''
        usage:%s --siteid=[value]
        or   : %s -s [value]

        siteadd sitedel (增加/删除新的站点)
        	-s,--siteid 指定站点siteid

        sitestatus 修改站点状态
        	-s,--siteid 指定站点siteid
        	-p,--status 指定站点状态码 0|1，A0代表正常状态，1代表暂停状态
	'''
	values = {}
	if len(sys.argv) < 4:
		print(help_info)
		exit(1)
	if sys.argv[1] == "siteadd" or sys.argv[1] == "sitedel":
		if len(sys.argv) != 4:
			print(help_info)
			exit(1)
		try:
			opts, args = getopt.getopt(sys.argv[2:], "s:h", ['siteid=','help='])
		except getopt.GetoptError as err:
	            print(help_info)
	            print("Error...")
	            print("请规范输入参量")
	            exit(1)
		for option,value in opts:
			if option in ["--siteid","-s"]:
				values["s"] = value
			else:
				print("Input Error...")
				print(help_info)
				exit(1)
			if judge_site_name(values["s"]) == 0:
				print("请输入规范的siteid[A-Za-z0-9_-]")
				exit(1)
	elif sys.argv[1] == "sitestatus":
		if len(sys.argv) != 6:
			print(help_info)
			exit(1)
		try:
			opts, args = getopt.getopt(sys.argv[2:], "s:p:h", ['siteid=','status=','help='])
		except getopt.GetoptError as err:
	            print(help_info)
	            print("Error...")
	            print("请规范输入参量")
	            exit(1)
		for option,value in opts:
			if option in ["--siteid","-s"]:
				values["s"] = value
			elif option in ["--status","-p"]:
				values["p"] = value
			else:
				print("Input Error...")
				print(help_info)
				exit(1)
	elif sys.argv[1] == "cacheflush":
		if len(sys.argv) != 4:
			print(help_info)
			exit(1)
		try:
			opts, args = getopt.getopt(sys.argv[2:], "s:h", ['siteid=','help='])
		except getopt.GetoptError as err:
	            print(help_info)
	            print("Error...")
	            print("请规范输入参量")
	            exit(1)
		for option,value in opts:
			if option in ["--siteid","-s"]:
				values["s"] = value
			else:
				print("Input Error...")
				print(help_info)
				exit(1)
			if judge_site_name(values["s"]) == 0:
				print("请输入规范的siteid[A-Za-z0-9_-]")
				exit(1)
	else:
		print(help_info)
		print("输入的参数有误，请确认后重试")
		exit(1)
	return values
			
def get_options_configdomain():
	help_info='''
        usage:%s domain --siteid=[value] --domain=[domain] --ip=[ip]
        or   : %s domain -s [value] -d [domain] -i [ip]

        domainadd 域名管理(添加)
        	-s,--siteid 指定站点
        	-d,--domain 指定域名,多个以逗号隔开
        	-i,--ip 指定指向的后端ip(注意加端口和不加端口的区别)

        domaindel 域名管理(删除)
        	-s,--siteid 指定站点
        	-d,--domain 指定域名,多个以逗号隔开
        	
	'''

	values = {}
	# print(len(sys.argv))
	if len(sys.argv) < 6:
		print(help_info)
		print('参数错误')
		exit(1)
	if sys.argv[1] == "domainadd":
		if len(sys.argv) < 8:
			print(help_info)
			print('参数错误')
			exit(1)
		try:
			opts, args = getopt.getopt(sys.argv[2:], "s:d:i:h:r", ['siteid=','domain=','ip=','help='])
		except getopt.GetoptError as err:
			print("Error...")
			print("请规范输入参量")
			exit(1)
		for option,value in opts:
			if option in ["--siteid","-s"]:
				values["s"] = value
			elif option in ["--domain", "-d"]:
				values["d"] = value
			elif option in ["--ip","-i"]:
				values["i"] = value
			else:
				print("Input Error...")
				exit(1)
	elif sys.argv[1] == "domaindel":
		if len(sys.argv) < 6:
			print(help_info)
			print('参数错误')
			exit(1)
		try:
			opts, args = getopt.getopt(sys.argv[2:], "s:d:h:r", ['siteid=','domain=','help='])
		except getopt.GetoptError as err:
			print("Error...")
			print("请规范输入参量")
			exit(1)
		for option,value in opts:
			if option in ["--siteid","-s"]:
				values["s"] = value
			elif option in ["--domain", "-d"]:
				values["d"] = value
			else:
				print("Input Error...")
				exit(1)
	else:
		print(help_info)
		print("输入参数错误，请确认后重试!!!")
		exit(1)
	return values

def get_options_configssl():
	help_info='''
        usage:%s domain --siteid=[value] --domain=[domain] --ip=[ip]
        or   : %s domain -s [value] -d [domain] -i [ip]

        sitessladd sitessldel 站点证书管理(sitessladd添加,sitessldel删除,如果指定所有域名删除，则会清理掉证书信息,相当于关闭证书,建议一本证书添加多个域名)
            -s,--siteid 指定站点
            -d,--domain 指定带有证书的域名,多个以逗号隔开

        domainssladd domainssldel 单个域名证书管理(ssladd添加,ssldel删除,不推荐在这里配置,后期管理比较麻烦;http--->https跳转默认加上,不需要单独添加301)
            -s,--siteid 指定站点
            -d,--domain 指定带有证书的域名,只能指定一个域名

        sslstatus 更新证书,更改相关证书(证书有续费更新时操作,会更新站点证书以及单独域名证书)
        	-s,--siteid 指定站点

	'''
	values = {}
	if len(sys.argv) < 4:
		print(help_info)
		exit(1)
	elif sys.argv[1] == "sitessladd" or sys.argv[1] == "sitessldel":
		try:
			opts, args = getopt.getopt(sys.argv[2:], "s:d:h", ['siteid=','domain=','help='])
		except getopt.GetoptError as err:
					print(help_info)
					print("Error...")
					print("请规范输入参量")
					exit(1)
		for option,value in opts:
			if option in ["--siteid","-s"]:
				values["s"] = value
			elif option in ["--domain", "-d"]:
				values["d"] = value
			else:
				print("Input Error...")
				print(help_info)
				exit(1)
	elif sys.argv[1] == "domainssladd" or sys.argv[1] == "domainssldel":
		try:
			opts, args = getopt.getopt(sys.argv[2:], "s:d:h", ['siteid=','domain=','help='])
		except getopt.GetoptError as err:
					print(help_info)
					print("Error...")
					print("请规范输入参量")
					exit(1)
		for option,value in opts:
			if option in ["--siteid","-s"]:
				values["s"] = value
			elif option in ["--domain", "-d"]:
				values["d"] = value
			else:
				print("Input Error...")
				print(help_info)
				exit(1)
		# print(len(values["d"].split(',')))
		if len(values["d"].split(',')) != 1:
			print("单独域名证书配置,域名只能指定一个,请确认后重试")
			print(help_info)
			exit(1)

	elif sys.argv[1] == "sslstatus":
		try:
			opts, args = getopt.getopt(sys.argv[2:], "s:t:n:h", ['siteid=','status=','number=','help='])
		except getopt.GetoptError as err:
			print(help_info)
			print("Error...")
			print("请规范输入参量")
			exit(1)
		for option,value in opts:
			if option in ["--siteid","-s"]:
				values["s"] = value
			else:
				print("Input Error...")
				print(help_info)
				exit(1)
	else:
		print("输入参数错误，请确认后重试!!!")
		exit(1)

	return values


if __name__ == '__main__':
	print(get_options_configsite())
	print(get_options_configdomain())
	print(get_options_configssl())
