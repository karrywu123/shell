# -*- coding:utf-8 -*-
# 功能：连接数据库，进行增、删、改、查

import sqlite3
import os
import platform

if platform.system() == "Linux":
    sqlitepath = "/vhs/kangle/etc/vhs.db"
else:
    sqlitepath = "vhs.db"
# sqlitepath = "/vhs/kangle/etc/vhs.db"

class MySqLite():
    """
    SQLite数据库是一款非常小巧的嵌入式开源数据库软件，也就是说没有独立的维护进程，所有的维护都来自于程序本身。
    在python中，使用sqlite3创建数据库的连接，当我们指定的数据库文件不存在的时候连接对象会自动创建数据库文件；
    如果数据库文件已经存在，则连接对象不会再创建数据库文件，而是直接打开该数据库文件。

    对于数据库链接对象来说，具有以下操作：
        commit()            --事务提交
        rollback()          --事务回滚
        close()             --关闭一个数据库链接
        cursor()            --创建一个游标

    cu = conn.cursor()
    这样我们就创建了一个游标对象：cu
    在sqlite3中，所有sql语句的执行都要在游标对象的参与下完成
    对于游标对象cu，具有以下具体操作：
        execute()           --执行一条sql语句
        executemany()       --执行多条sql语句
        close()             --游标关闭
        fetchone()          --从结果中取出一条记录
        fetchmany()         --从结果中取出多条记录
        fetchall()          --从结果中取出所有记录
        scroll()            --游标滚动
        update()            --更新数据
        delete()             --删除数据

    """
    # 是否打印sql
    # SHOW_SQL = False

    if platform.system() == "Linux":
        SHOW_SQL = False
    else:
        SHOW_SQL = True

    def __init__(self):
        self.path = sqlitepath

    def get_conn(self):
        """
        获取数据库连接
        """
        try:
            conn = sqlite3.connect(self.path)
            """
            该参数是为了解决一下错误：
            ProgrammingError: You must not use 8-bit bytestrings unless you use a text_factory that can interpret 8-bit bytestrings (like text_factory = str).
            It is highly recommended that you instead just switch your application to Unicode strings.
            """
            # conn.text_factory = lambda x: unicode(x, 'utf-8', 'ignore')

            conn.text_factory = str
            if os.path.exists(self.path) and os.path.isfile(self.path):
                if platform.system() == "Linux":
                    pass
                else:
                    print('硬盘上面:[{}]'.format(self.path))
                
                return conn
        # except sqlite3.OperationalError, e:
        except  e:
            print("Error:%s" % e)
    def get_cursor(self, conn):
        """
        该方法是获取数据库的游标对象，参数为数据库的连接对象
        """
        if conn is not None:
            return conn.cursor()
        else:
            return self.get_conn().cursor()


    def close_all(self, conn, cu):
        """
        关闭数据库游标对象和数据库连接对象
        """
        try:
            cu.close()
            conn.close()
        # except sqlite3.OperationalError, e:
        except  e:
            print("Error:%s" % e)


    def create_table(self, sql):
        """
        创建数据库表
        """
        if sql is not None and sql != '':
            conn = self.get_conn()
            cu = self.get_cursor(conn)
            if self.SHOW_SQL:
                print('执行sql:[{}]'.format(sql))
            cu.execute(sql)
            conn.commit()
            print('创建数据库表[cndba]成功!')
            self.close_all(conn, cu)
        else:
            print('the [{}] is empty or equal None!'.format(sql))

    def drop_table(self, table):
        """
        如果表存在,则删除表
        """
        if table is not None and table != '':
            sql = 'DROP TABLE IF EXISTS ' + table
            if self.SHOW_SQL:
                print('执行sql:[{}]'.format(sql))
            conn = self.get_conn()
            cu = self.get_cursor(conn)
            cu.execute(sql)
            conn.commit()
            print('删除数据库表[{}]成功!'.format(table))
            cu.close()
            conn.close()
            # self.close_all(conn, cu)
        else:
            print('the [{}] is empty or equal None!'.format(sql))

    def insert(self, sql, data):
        """
        插入数据
        """
        if sql is not None and sql != '':
            if data is not None:
                conn = self.get_conn()
                cu = self.get_cursor(conn)
                for d in data:
                    if self.SHOW_SQL:
                        print('执行sql:[{}],参数:[{}]'.format(sql, d))
                cu.execute(sql, data)
                conn.commit()
                self.close_all(conn, cu)
        else:
            print('the [{}] is empty or equal None!'.format(sql))

    def fetchall(self, sql):
        """
        查询所有数据
        """
        if sql is not None and sql != '':
            conn = self.get_conn()
            cu = self.get_cursor(conn)
            if self.SHOW_SQL:
                print('执行sql:[{}]'.format(sql))
            cu.execute(sql)
            r = cu.fetchall()
            return r
            # print r
            # if len(r) > 0:
            #     for e in range(len(r)):
            #         print(r[e])
            self.close_all(conn, cu)
        else:
            print('the [{}] is empty or equal None!'.format(sql))

    def fetchone(self, sql, data):
        """
        查询一条数据
        """
        if sql is not None and sql != '':
            if data is not None:
                #Do this instead
                d = (data,)
                conn = self.get_conn()
                cu = self.get_cursor(conn)
                if self.SHOW_SQL:
                    print('执行sql:[{}],参数:[{}]'.format(sql, data))
                cu.execute(sql, d)
                r = cu.fetchall()
                print(r)
                if len(r) > 0:
                    for e in range(len(r)):
                        print(r[e])
                self.close_all(conn, cu)
            else:
                print('the [{}] equal None!'.format(data))
        else:
            print('the [{}] is empty or equal None!'.format(sql))

    def update(self, sql, data):
        """
        更新数据
        """
        if sql is not None and sql != '':
            if data is not None:
                conn = self.get_conn()
                cu = self.get_cursor(conn)
                d_tmp = []
                for d in data:
                    if self.SHOW_SQL:
                        print('执行sql:[{}],参数:[{}]'.format(sql, d))                   
                    d_tmp.append(d)
                cu.execute(sql, d_tmp)
                conn.commit()
                self.close_all(conn, cu)
        else:
            print('the [{}] is empty or equal None!'.format(sql))

    def delete(self, sql, data):
        """
        删除数据
        """
        if sql is not None and sql != '':
            if data is not None:
                conn = self.get_conn()
                cu = self.get_cursor(conn)
                d_tmp = []
                for d in data:
                    if self.SHOW_SQL:
                        print('执行sql:[{}],参数:[{}]'.format(sql, d))                 
                    d_tmp.append(d)
                cu.execute(sql, d_tmp)
                conn.commit()
                self.close_all(conn, cu)
        else:
            print('the [{}] is empty or equal None!'.format(sql))


###########################################################
#查询所有站点
def getAllSite():
    sql = "select name from vhost"
    db = MySqLite()
    res = db.fetchall(sql)
    return res

# 查询某个站点
def get_Site(site):
    sql = "select name from vhost where name='{}'".format(site)
    db = MySqLite()
    res = db.fetchall(sql)
    return res

#站点插入
def insert_vhost(data):
    sql = 'INSERT INTO "main"."vhost"("name", "doc_root", "uid", "gid", "status", "htaccess", "access", "max_connect", "speed_limit", "max_worker", "max_queue", "log_file", "flow", "hcount", "cs", "envs", "log_handle", "flow_limit", "certificate", "certificate_key", "cipher", "protocols", "fflow", "http2", "pgid_four", "log_rotate_time", "node_router", "early_data") VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)'
    db = MySqLite()
    res = db.insert(sql,data)
    return res

#站点基本信息插入,为默认固定值,类型根据name字段区分
def insert_vhost_config(data):
    # print(type(https_data))
    sql = "INSERT INTO 'main'.'vhost_config'('vhost', 'name', 'id', 'value') VALUES (?,?,?,?);"
    db = MySqLite()
    res = db.insert(sql,data)
    return res

###########################################################
#删除站点vhost
def delete_site_vhost(data):
    sql = 'DELETE from "main"."vhost" WHERE name = ?'
    db = MySqLite()
    res = db.delete(sql,data)
    return res

#删除站点vhost_config
def delete_site_vhost_config(data):
    sql = 'DELETE from "main"."vhost_config" WHERE vhost = ?'
    db = MySqLite()
    res = db.delete(sql,data)
    return res

#删除站点domain表数据
def delete_site_domain(data):
    sql = 'DELETE from "main"."domain" WHERE vhost = ?'
    db = MySqLite()
    res = db.delete(sql,data)
    return res

#删除站点vhost_info
def delete_site_vhost_info(data):
    sql = 'DELETE from "main"."vhost_info" WHERE vhost = ?'
    db = MySqLite()
    res = db.delete(sql,data)
    return res

#删除站点vhost_port
def delete_site_vhost_port(data):
    sql = 'DELETE from "main"."vhost_port" WHERE vhost = ?'
    db = MySqLite()
    res = db.delete(sql,data)
    return res

#修改站点状态
def update_vhost_status__from_vhost(data):
    sql = 'UPDATE "main"."vhost" SET "status" = ? WHERE "name" = ?;'
    db = MySqLite()
    res = db.update(sql,data)
    return res

# 查询某个站点状态
def get_site_status(site):
    sql = "select status from vhost where name='{}'".format(site)
    db = MySqLite()
    res = db.fetchall(sql)
    return res

###########################################################

# 查询某个站点的域名id
def get_domain_id_from_site(site):
    sql = "select id from domain where vhost=" + '"' + site + '"'
    # print(sql)
    db = MySqLite()
    res = db.fetchall(sql)
    return res

# 查询某个站点的域名
def get_domain_from_site(site,mydomain):
    sql = "select domain,value from domain where vhost='{}' and domain='{}'".format(site,mydomain)
    db = MySqLite()
    res = db.fetchall(sql)
    return res

# 查询所有站点的某个域名
def get_domain_from_all_site(mydomain):
    sql = "select vhost,domain from domain where domain='{}'".format(mydomain)
    db = MySqLite()
    res = db.fetchall(sql)
    return res

# 查询vhost_info表的域名value列
def get_vhost_info_domain(site,mydomain):
    sql = "select value from vhost_info where vhost='{}'  and name='{}'".format(site,mydomain)
    # print(sql)
    db = MySqLite()
    res = db.fetchall(sql)
    return res

# 查询域名信息域名对应value
def get_domain_info_from_all_site(mydomain,value):
    sql = "select vhost,domain from domain where domain='{}' and value='{}'".format(mydomain,value)
    db = MySqLite()
    res = db.fetchall(sql)
    return res

#插入域名信息到vhost_info
def insert_to_vhost_info(data):
    sql = 'INSERT INTO "main"."vhost_info"("vhost", "name", "type", "value", "id") VALUES (?,?,?,?,?);'
    db = MySqLite()
    # print(sql)
    res = db.insert(sql,data)

# 插入域名信息到domain表
def insert_to_domian(data):
    sql = 'INSERT INTO "main"."domain"("vhost", "id", "domain", "value", "t", "status", "public_setting", "private_setting") VALUES (?,?,?,?,0, 0,"''", NULL);'
    db = MySqLite()
    # print(sql)
    res = db.insert(sql,data)
    return res

# 更新vhost_info表数据
def update_domain_info_from_vhost_info(data):
    sql = 'UPDATE "main"."vhost_info" SET "vhost" = ?, "name" = ?, "type" = ?, "value" = ?, "id" = ? WHERE "vhost" = "{}" AND "name" = "{}";'.format(data[0],data[1])
    db = MySqLite()
    # print(sql)
    res = db.update(sql,data)
    return res

#删除domain表域名
def delete_domain_from_domain(data):
    sql = 'DELETE from "main"."domain" WHERE domain = ?'
    db = MySqLite()
    res = db.delete(sql,data)
    return res

#删除vhost_info表域名
def delete_domian_from_vhost_info(data):
    sql = 'DELETE from "main"."vhost_info" WHERE "name" = ?'
    db = MySqLite()
    res = db.delete(sql,data)
    return res

# 查询vhost_info表站点443配置
def get_vhost_info_443_config(site):
    sql = "select vhost,name from vhost_info where vhost='{}' and name='!*:443s'".format(site)
    db = MySqLite()
    res = db.fetchall(sql)
    return res

# 插入443端口配置到vhost_info
def insert_to_vhost_info_ssl_config(data):
    sql = 'INSERT INTO "main"."vhost_info"("vhost", "name", "type", "value", "id") VALUES (?,"!*:443s","7",NULL,"0");'
    db = MySqLite()
    res = db.insert(sql,data)

# 插入80端口配置到vhost_info
def insert_vhost_info_80_config(data):
    sql = 'INSERT INTO "main"."vhost_info"("vhost", "name", "type", "value", "id") VALUES (?,"!*:80","7",NULL,"0");'
    db = MySqLite()
    res = db.insert(sql,data)


###########################################################站点证书操作相关
#更新vhost站点https配置,设置证书文件名称"certificate", "certificate_key"
def update_vhost_ssl(sitename,data):
    sql = 'UPDATE "main"."vhost" SET "certificate" = ?, "certificate_key" = ? WHERE "name" = "{}"'.format(sitename)
    db = MySqLite()
    res = db.update(sql,data)
    return res

#更新vhost_config证书具体配置，更新证书，从文件读取
def update_vhost_config_ssl(sitename,https_data):
    sql = "UPDATE 'main'.'vhost_config' SET value = '{}'  WHERE name = ? AND vhost = ?;".format(https_data)
    db = MySqLite()
    # print(sql)
    res = db.update(sql,["https",sitename])
    return res
#查询vhost_config https记录
def select_vhost_config_ssl(sitename):
    sql = "select id,value from vhost_config where vhost='{}' and name='{}'".format(sitename,"https")
    db = MySqLite()
    res = db.fetchall(sql)
    return res


#插入vhost_config证书配置,使用insert_vhost_config函数
# def insert_vhost_config_ssl(data):
def insert_vhost_config_ssl(data,https_data):
    # print(type(https_data))
    sql = "INSERT INTO 'main'.'vhost_config'('vhost', 'name', 'id', 'value') VALUES (?,?,?,'{}');".format(https_data)
    db = MySqLite()
    res = db.insert(sql,data)
    return res
#删除vhost_config证书配置
def delete_vhost_config_ssl(data):
    pass

#查询站点证书配置所有301重写情况
def select_vhost_config_301(sitename):
    sql = "select id,value from vhost_config where vhost='{}' and name='{}'".format(sitename,"redirect")
    db = MySqLite()
    res = db.fetchall(sql)
    return res
#插入站点证书配置301重写情况,使用insert_vhost_config函数
def insert_vhost_config_301(data,data_301):
    # print(type(https_data))
    sql = "INSERT INTO 'main'.'vhost_config'('vhost', 'name', 'id', 'value') VALUES (?,?,?,'{}');".format(data_301)
    db = MySqLite()
    res = db.insert(sql,data)
    return res
#删除301重写,删除时或者关闭时操作
def delete_vhost_config_301(data):
    sql = 'DELETE from "main"."vhost_config" WHERE "vhost" = ? AND "name" = ? AND "id" = ?'
    db = MySqLite()
    res = db.delete(sql,data)
    return res
###########################################################
###########################################################域名证书操作相关
#查询单独域名证书状态domain
def select_domain_setting_from_site(sitename,domain):
    sql = "select domain,value,public_setting from domain where vhost='{}' and domain='{}'".format(sitename,domain)
    db = MySqLite()
    res = db.fetchall(sql)
    return res
#更新域名证书信息
def update_domain_setting_from_site(sitename,domain,https_data):
    sql = "UPDATE 'main'.'domain' SET 'public_setting' = '{}'  WHERE vhost = ? AND domain = ?;".format(https_data)
    db = MySqLite()
    res = db.update(sql,[sitename,domain])
    return res

# 更新vhost_info表数据
def update_domain_info_https_from_vhost_info(sitename,domain,data):
    sql = 'UPDATE "main"."vhost_info" SET "value" = ? WHERE "vhost" = "{}" AND "name" = "{}";'.format(sitename,domain)
    db = MySqLite()
    res = db.update(sql,data)
    return res
#查询某个站点所有域名
def select_all_domain_setting_from_site(sitename):
    sql = "select domain,value,public_setting from domain where vhost='{}'".format(sitename)
    db = MySqLite()
    res = db.fetchall(sql)
    return res
###########################################################


